package com.ggbg.note.bean;

import lombok.Data;

@Data
public class LoginViewModel {
	private String email;
	
	private String password;
}
