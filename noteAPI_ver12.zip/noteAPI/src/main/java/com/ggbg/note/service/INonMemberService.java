package com.ggbg.note.service;

import com.ggbg.note.bean.Account;

public interface INonMemberService {
	// signUp process
	public boolean signUp(Account account);

	public boolean emailCheck(String email);

	public boolean emailAuthSend(String email);

	public boolean emailAuthCheck(String email, String authNum);

}
