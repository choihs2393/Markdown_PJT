package com.ggbg.note.exception;

public class UnAuthorizationException extends RuntimeException {
	public UnAuthorizationException(String msg) {
		super(msg);
	}
}
