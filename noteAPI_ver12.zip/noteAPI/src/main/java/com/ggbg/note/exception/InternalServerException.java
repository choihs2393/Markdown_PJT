package com.ggbg.note.exception;

public class InternalServerException extends RuntimeException {
	public InternalServerException(String msg) {
		super(msg);
	}
}
