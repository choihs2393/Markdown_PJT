package com.ggbg.note.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ggbg.note.util.JwtTokenUtil;

@RequestMapping("/band")
@RestController
public class BandController {
	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

//	@Autowired
//	private IAccountService accountService;

	@Autowired
	private JwtTokenUtil jwt;
	
	// 만들어야할것
	// band 초대 승인 눌렀을때 추가 ( band update, account_band update)
	// 멤버 보여주기
}
