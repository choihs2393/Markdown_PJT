package com.ggbg.note.exception;

public class UnknownException extends RuntimeException{

	public UnknownException(String msg) {
		super(msg);
	}
}
